fftools/textformat/tf_default.o: src/fftools/textformat/tf_default.c \
 src/fftools/textformat/avtextformat.h src/libavutil/dict.h \
 src/libavformat/avio.h src/libavutil/attributes.h src/libavutil/log.h \
 src/libavutil/attributes.h src/libavutil/version.h \
 src/libavutil/macros.h libavutil/avconfig.h \
 src/libavformat/version_major.h src/libavutil/bprint.h \
 src/libavutil/avstring.h src/libavutil/rational.h src/libavutil/hash.h \
 src/fftools/textformat/avtextwriters.h src/libavutil/avutil.h \
 src/libavutil/common.h src/libavutil/error.h src/libavutil/mem.h \
 src/libavutil/rational.h src/libavutil/mathematics.h \
 src/libavutil/intfloat.h src/libavutil/log.h src/libavutil/pixfmt.h \
 src/libavutil/opt.h src/libavutil/channel_layout.h src/libavutil/dict.h \
 src/libavutil/samplefmt.h src/fftools/textformat/tf_internal.h
