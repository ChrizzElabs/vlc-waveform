fftools/textformat/tw_buffer.o: src/fftools/textformat/tw_buffer.c \
 src/fftools/textformat/avtextwriters.h src/libavformat/avio.h \
 src/libavutil/attributes.h src/libavutil/dict.h src/libavutil/log.h \
 src/libavutil/attributes.h src/libavutil/version.h \
 src/libavutil/macros.h libavutil/avconfig.h \
 src/libavformat/version_major.h src/libavutil/bprint.h \
 src/libavutil/avstring.h src/libavutil/opt.h src/libavutil/rational.h \
 src/libavutil/channel_layout.h src/libavutil/dict.h src/libavutil/log.h \
 src/libavutil/pixfmt.h src/libavutil/samplefmt.h
