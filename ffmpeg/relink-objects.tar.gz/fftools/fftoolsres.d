fftools/fftoolsres.o: src/fftools/fftoolsres.rc
