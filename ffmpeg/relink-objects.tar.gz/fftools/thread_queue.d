fftools/thread_queue.o: src/fftools/thread_queue.c \
 src/libavutil/avassert.h src/libavutil/attributes.h src/libavutil/log.h \
 src/libavutil/version.h src/libavutil/macros.h libavutil/avconfig.h \
 src/libavutil/container_fifo.h src/libavutil/error.h \
 src/libavutil/fifo.h src/libavutil/frame.h src/libavutil/avutil.h \
 src/libavutil/common.h src/libavutil/error.h src/libavutil/mem.h \
 src/libavutil/rational.h src/libavutil/mathematics.h \
 src/libavutil/intfloat.h src/libavutil/pixfmt.h src/libavutil/buffer.h \
 src/libavutil/channel_layout.h src/libavutil/dict.h \
 src/libavutil/samplefmt.h src/libavutil/intreadwrite.h \
 src/libavutil/bswap.h src/libavutil/mem.h src/libavutil/thread.h \
 config.h src/compat/w32pthreads.h src/libavutil/attributes.h \
 src/libavutil/common.h src/libavutil/internal.h src/libavutil/libm.h \
 src/libavutil/time.h src/libavutil/wchar_filename.h \
 src/libavcodec/packet.h src/libavutil/buffer.h src/libavutil/dict.h \
 src/libavutil/rational.h src/libavutil/version.h \
 src/libavcodec/version_major.h src/fftools/thread_queue.h
