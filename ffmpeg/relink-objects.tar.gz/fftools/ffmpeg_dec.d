fftools/ffmpeg_dec.o: src/fftools/ffmpeg_dec.c src/compat/stdbit/stdbit.h \
 src/libavutil/avassert.h src/libavutil/attributes.h src/libavutil/log.h \
 src/libavutil/version.h src/libavutil/macros.h libavutil/avconfig.h \
 src/libavutil/avstring.h src/libavutil/dict.h src/libavutil/error.h \
 src/libavutil/log.h src/libavutil/mem.h src/libavutil/opt.h \
 src/libavutil/rational.h src/libavutil/channel_layout.h \
 src/libavutil/dict.h src/libavutil/pixfmt.h src/libavutil/samplefmt.h \
 src/libavutil/pixdesc.h src/libavutil/pixfmt.h src/libavutil/stereo3d.h \
 src/libavutil/frame.h src/libavutil/avutil.h src/libavutil/common.h \
 src/libavutil/error.h src/libavutil/mem.h src/libavutil/mathematics.h \
 src/libavutil/intfloat.h src/libavutil/buffer.h src/libavutil/time.h \
 src/libavutil/timestamp.h src/libavcodec/avcodec.h \
 src/libavutil/samplefmt.h src/libavutil/attributes.h \
 src/libavutil/avutil.h src/libavutil/buffer.h \
 src/libavutil/channel_layout.h src/libavutil/frame.h \
 src/libavutil/rational.h src/libavcodec/codec.h \
 src/libavutil/hwcontext.h src/libavcodec/codec_id.h \
 src/libavcodec/codec_id.h src/libavcodec/defs.h src/libavcodec/packet.h \
 src/libavutil/version.h src/libavcodec/version_major.h \
 src/libavcodec/version_major.h src/libavcodec/version.h \
 src/libavcodec/codec_desc.h src/libavcodec/codec_par.h \
 src/libavcodec/codec.h src/fftools/ffmpeg.h config.h \
 src/fftools/cmdutils.h src/libavfilter/avfilter.h \
 src/libavfilter/version_major.h src/libavfilter/version.h \
 src/libavfilter/version_major.h src/libavformat/avformat.h \
 src/libavcodec/codec_par.h src/libavcodec/defs.h src/libavcodec/packet.h \
 src/libavformat/avio.h src/libavformat/version_major.h \
 src/libavformat/version.h src/libavformat/version_major.h \
 src/libswscale/swscale.h src/libswscale/version_major.h \
 src/libswscale/version.h src/fftools/ffmpeg_sched.h \
 src/fftools/ffmpeg_utils.h src/libavutil/common.h \
 src/fftools/sync_queue.h src/libavformat/avio.h src/libavcodec/bsf.h \
 src/libavutil/bprint.h src/libavutil/avstring.h src/libavutil/eval.h \
 src/libavutil/fifo.h src/libavutil/thread.h src/compat/w32pthreads.h \
 src/libavutil/internal.h src/libavutil/libm.h \
 src/libavutil/wchar_filename.h src/libavutil/threadmessage.h \
 src/libswresample/swresample.h src/libswresample/version_major.h \
 src/libswresample/version.h src/libswresample/version_major.h
